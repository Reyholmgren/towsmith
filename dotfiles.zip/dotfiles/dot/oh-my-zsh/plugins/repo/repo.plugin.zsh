# Aliases
alias r='repo'
