# using the rbenv plugin will override this with a real implementation
function rbenv_prompt_info() {}
