# vice-colorful
Collection of vim colorschemes for [vice][vice] (but should be usable with
vim-addon-manager or pathogen or the like).

Normalized as much as possible. Great fun with
[vim-color-switch][vim-color-switch]!

[vice]: https://github.com/zeekay/vice
[vim-color-switch]: https://github.com/zeekay/vim-color-switch
