# This is only here to fool vim-rails into syntax highlighting "has_many", etc.
