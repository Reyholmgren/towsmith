class Foo
  # this is a comment with no end
end
