class Foo
  answer
  if true
    'yes'
  else
    'no'
  end
end
