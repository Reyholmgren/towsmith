[1,2,3,4,5].map do |i|
  i + 1
end.max
